suma.dos.numeros<-function(a,b)
{
  return(a + b)
}

